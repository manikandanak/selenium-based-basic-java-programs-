package com.example.tests;


import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;


public class SecondLargest {
	private static int largets;

	
public static void main(String[] args) {
	
	
	ArrayList arrayList=new ArrayList();
	
	arrayList.add(2);
	arrayList.add(5);
	arrayList.add(8);
	arrayList.add(4);
	arrayList.add(21);
	arrayList.add(10);
	
	int lenth=arrayList.size();
	for(Object temp:arrayList)
	{
	
	}

	
	
	System.out.println("Array Element is ::::"+ arrayList);
}}
