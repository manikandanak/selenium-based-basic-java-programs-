package com.example.tests;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.collections.map.HashedMap;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class CollectionArrayList {

	public static void main(String arg[]) {

		System.out.println("Enter the values to swap");
		Scanner scn=new Scanner(System.in);
		
   int a,b,c;
    
   a=a+b;
   b=a-b;
   a=a-b;
    System.out.println("Swaped Values are"+"\n"+a +"\n"+b);  
   }  
  }  

